# The Signal — Forge 1.20.1 (V2 development build)

Analog-horror survival mod source for Minecraft Java 1.20.1 / Forge 47.2.0 / Java 17.

## Build
Open this folder as a Gradle project in IntelliJ IDEA, with a Java 17 toolchain, then run `gradle build` (or the included wrapper if supplied). The output JAR is in `build/libs/`. This archive does **not** include a Gradle wrapper. The current editing environment did not have Gradle installed, so this revision has not been compiled or game-tested.

## Current features in source
- Custom 3D humanoid Stalker entity with a 64x64 texture.
- Server-side encounter starts 30 seconds after player join; later encounter timer is randomized.
- Stalker AI pursues and teleports around players.
- Flashlight item toggles its saved on/off state and renders a client-side particle cone when held (visual beam only; it does not illuminate blocks).
- Shotgun has a cooldown, firing sound, aim-cone/line-of-sight damage check and knockback.
- Client atmospheric fog, low rumble ambience, heartbeat cue when health is low, red glitch overlay and angular screen-fracture effect.
- Original synthesized sound assets; crafting recipes and item textures.

## Commands
- `/signal test` — spawn a Stalker near the player.
- `/signal jumpscare` — test warning message.
- `/signal reset` — restart the encounter intro timer.

## Controls
- Right-click flashlight to toggle its stored state.
- Right-click shotgun to fire.

## Important limitations / next work
- The flashlight state is implemented, but **dynamic world illumination / a visible focused beam is not**. Vanilla Forge does not provide dynamic lights for ordinary item code; use a compatible dynamic-lights library or implement a client render beam.
- Fog is applied client-side in loaded worlds; exact look and compatibility need in-game verification.
- Screen fractures are procedural overlay lines, not a detailed cracked-glass texture.
- Audio timing is client-side ambience; dedicated-server and multiplayer behavior still needs testing.
- Encounter timing, stalker distance logic, item balance, recipes, and rendering need an actual Forge build and in-game QA.
- This is a development source archive, not a verified ready-to-install JAR.
