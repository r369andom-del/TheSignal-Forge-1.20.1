package com.thesignal.event;

import com.thesignal.entity.StalkerEntity;
import com.thesignal.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.commands.Commands;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Mod.EventBusSubscriber
public class CommonEvents {
    private static final Map<UUID, Integer> JOIN_TICKS = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> NEXT_EVENT = new ConcurrentHashMap<>();

    @SubscribeEvent
    public static void onJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            JOIN_TICKS.put(player.getUUID(), 0);
            NEXT_EVENT.put(player.getUUID(), 600);
            player.displayClientMessage(Component.literal("§7...something is wrong with this world."), false);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        JOIN_TICKS.remove(event.getEntity().getUUID());
        NEXT_EVENT.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        Player player = event.player;
        UUID id = player.getUUID();
        if (!JOIN_TICKS.containsKey(id)) return;

        int ticks = JOIN_TICKS.merge(id, 1, Integer::sum);
        int next = NEXT_EVENT.getOrDefault(id, 600);
        if (ticks == 600) player.displayClientMessage(Component.literal("§4DON'T LOOK OUTSIDE."), false);

        if (ticks >= next) {
            if (player.level() instanceof net.minecraft.server.level.ServerLevel server) {
                StalkerEntity entity = ModEntities.STALKER.get().create(server);
                if (entity != null) {
                    double a = player.getRandom().nextDouble() * Math.PI * 2;
                    double r = 12 + player.getRandom().nextDouble() * 8;
                    entity.moveTo(player.getX() + Math.cos(a)*r, player.getY(), player.getZ() + Math.sin(a)*r,
                            player.getYRot(), 0);
                    server.addFreshEntity(entity);
                    player.displayClientMessage(Component.literal("§4§lSOMETHING HAS FOUND YOU"), false);
                }
            }
            NEXT_EVENT.put(id, ticks + 400 + player.getRandom().nextInt(2001));
        }
    }

    @SubscribeEvent
    public static void registerCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("signal")
                .then(Commands.literal("test").executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    StalkerEntity entity = ModEntities.STALKER.get().create(player.serverLevel());
                    if (entity != null) {
                        entity.moveTo(player.getX()+14, player.getY(), player.getZ(), player.getYRot(), 0);
                        player.serverLevel().addFreshEntity(entity);
                    }
                    player.displayClientMessage(Component.literal("§4THE SIGNAL IS ACTIVE"), false);
                    return 1;
                }))
                .then(Commands.literal("jumpscare").executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal("§4§lLOOK BEHIND YOU."), false);
                    return 1;
                }))
                .then(Commands.literal("reset").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    JOIN_TICKS.put(p.getUUID(), 0);
                    NEXT_EVENT.put(p.getUUID(), 600);
                    return 1;
                })));
    }
}
