package com.thesignal.entity;

import com.thesignal.registry.ModEntities;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class StalkerEntity extends Mob {
    private int teleportCooldown = 100;
    private int stareTicks = 0;

    public StalkerEntity(EntityType<? extends Mob> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 90.0)
                .add(Attributes.MOVEMENT_SPEED, 0.34)
                .add(Attributes.ATTACK_DAMAGE, 8.0)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override protected void registerGoals() {
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.18, false));
        goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.85));
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 32.0F));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
    }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel server)) return;
        Player player = server.getNearestPlayer(this, 40.0);
        if (player == null || player.isCreative() || player.isSpectator()) return;

        double distance = distanceTo(player);
        if (distance > 20.0) {
            getNavigation().moveTo(player, 1.18);
        } else if (distance < 10.0) {
            getNavigation().stop();
            lookAt(player, 180, 180);
            if (++stareTicks > 35) {
                teleportNear(player);
                stareTicks = 0;
            }
        } else {
            getNavigation().stop();
            lookAt(player, 180, 180);
            if (random.nextInt(100) == 0) player.displayClientMessage(
                    Component.literal("§4§kTHE SIGNAL§r §cIS STILL HERE"), true);
        }

        if (--teleportCooldown <= 0) {
            if (distance > 12 && distance < 38 && random.nextFloat() < 0.45F) teleportNear(player);
            teleportCooldown = 100 + random.nextInt(100);
        }
    }

    private void teleportNear(Player player) {
        for (int i = 0; i < 12; i++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double radius = 11 + random.nextDouble() * 8;
            double x = player.getX() + Math.cos(angle) * radius;
            double z = player.getZ() + Math.sin(angle) * radius;
            int y = level().getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING, (int)x, (int)z);
            if (level().noCollision(this, getBoundingBox().move(x - getX(), y - getY(), z - getZ()))) {
                teleportTo(x, y, z);
                return;
            }
        }
    }

    @Override public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        return super.doHurtTarget(target);
    }
}
