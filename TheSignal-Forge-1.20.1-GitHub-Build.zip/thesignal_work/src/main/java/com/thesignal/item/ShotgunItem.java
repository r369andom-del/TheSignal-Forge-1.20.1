package com.thesignal.item;

import com.thesignal.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class ShotgunItem extends Item {
    public ShotgunItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }
        if (!level.isClientSide) {
            Vec3 start = player.getEyePosition();
            Vec3 look = player.getLookAngle();
            Vec3 end = start.add(look.scale(18.0));
            AABB area = new AABB(start, end).inflate(1.5);
            LivingEntity best = null;
            double bestDistance = 19.0;
            for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, area,
                    e -> e != player && e.isAlive())) {
                Vec3 point = target.position().add(0, target.getBbHeight() * 0.5, 0);
                Vec3 delta = point.subtract(start);
                double distance = delta.length();
                if (distance < bestDistance && look.dot(delta.normalize()) > 0.965
                        && level.clip(new net.minecraft.world.level.ClipContext(start, point,
                        net.minecraft.world.level.ClipContext.Block.COLLIDER,
                        net.minecraft.world.level.ClipContext.Fluid.NONE, player)).getType()
                        == net.minecraft.world.phys.HitResult.Type.MISS) {
                    best = target;
                    bestDistance = distance;
                }
            }
            if (best != null) {
                best.hurt(level.damageSources().playerAttack(player), 24.0F);
                best.knockback(1.8, player.getX() - best.getX(), player.getZ() - best.getZ());
            }
            level.playSound(null, player.blockPosition(), ModSounds.SHOTGUN.get(),
                    SoundSource.PLAYERS, 1.0F, 0.9F + player.getRandom().nextFloat() * 0.2F);
            player.getCooldowns().addCooldown(this, 24);
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            player.displayClientMessage(Component.literal(best != null ? "BOOM! IT BLEEDS." :
                    "BOOM! THE FOG SWALLOWS THE SHOT.").withStyle(ChatFormatting.DARK_RED), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
