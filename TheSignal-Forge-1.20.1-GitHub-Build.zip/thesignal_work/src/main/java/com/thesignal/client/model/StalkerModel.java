package com.thesignal.client.model;

import com.thesignal.TheSignal;
import com.thesignal.entity.StalkerEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class StalkerModel extends HierarchicalModel<StalkerEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(TheSignal.MODID, "stalker"), "main");
    private final ModelPart root, head, body, leftArm, rightArm, leftLeg, rightLeg;

    public StalkerModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0,0)
                .addBox(-4,-8,-4,8,8,8), PartPose.offset(0,0,0));
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0,16)
                .addBox(-4,0,-2,8,14,4), PartPose.ZERO);
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(24,16)
                .addBox(-1,-2,-2,3,18,3), PartPose.offset(5,2,0));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(24,16)
                .addBox(-2,-2,-2,3,18,3), PartPose.offset(-5,2,0));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(40,16)
                .addBox(-1,0,-2,3,18,3), PartPose.offset(2,14,0));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(40,16)
                .addBox(-2,0,-2,3,18,3), PartPose.offset(-2,14,0));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override public void setupAnim(StalkerEntity entity, float limbSwing, float limbSwingAmount,
                                    float ageInTicks, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        head.xRot = headPitch * Mth.DEG_TO_RAD;
        leftLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        rightLeg.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
        leftArm.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
        rightArm.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        body.xRot = 0.08F;
    }

    @Override public ModelPart root() { return root; }
}
