package com.thesignal.client;

import com.thesignal.TheSignal;
import com.thesignal.entity.StalkerEntity;
import com.thesignal.client.model.StalkerModel;
import com.thesignal.registry.ModEntities;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TheSignal.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(StalkerModel.LAYER_LOCATION, StalkerModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.STALKER.get(), ctx ->
                new MobRenderer<StalkerEntity, StalkerModel>(ctx, new StalkerModel(ctx.bakeLayer(StalkerModel.LAYER_LOCATION)), 0.6F) {
                    @Override public ResourceLocation getTextureLocation(StalkerEntity entity) {
                        return new ResourceLocation(TheSignal.MODID, "textures/entity/stalker.png");
                    }
                });
    }
}
