package com.thesignal.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.thesignal.TheSignal;
import com.thesignal.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;\nimport net.minecraft.core.particles.ParticleTypes;\nimport com.thesignal.registry.ModItems;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Random;

@Mod.EventBusSubscriber(modid = TheSignal.MODID, value = Dist.CLIENT)
public class ClientEvents {
    private static int distortion = 0;
    private static int ambientCooldown = 900;
    private static int heartbeatCooldown = 0;
    private static final Random RANDOM = new Random();

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        if (distortion > 0) distortion--;

        // Client-only visible flashlight cone. Vanilla particles do not light blocks;
        // this gives the player a visible beam without requiring a dynamic-light mod.
        var held = mc.player.getMainHandItem();
        var offhand = mc.player.getOffhandItem();
        boolean flashlightOn = (held.is(ModItems.FLASHLIGHT.get()) && held.hasTag()
                && held.getTag().getBoolean("LightOn"))
                || (offhand.is(ModItems.FLASHLIGHT.get()) && offhand.hasTag()
                && offhand.getTag().getBoolean("LightOn"));
        if (flashlightOn && mc.level.getGameTime() % 2 == 0) {
            var eye = mc.player.getEyePosition();
            var look = mc.player.getLookAngle();
            for (int step = 2; step <= 12; step += 2) {
                double spread = step * 0.025;
                double side = (RANDOM.nextDouble() - 0.5) * spread;
                double up = (RANDOM.nextDouble() - 0.5) * spread;
                var point = eye.add(look.scale(step)).add(side, up, side);
                mc.level.addParticle(ParticleTypes.END_ROD, point.x, point.y, point.z, 0, 0, 0);
            }
        }

        if (--ambientCooldown <= 0) {
            mc.level.playLocalSound(mc.player.blockPosition(), ModSounds.LOW_RUMBLE.get(),
                    SoundSource.AMBIENT, 0.55F, 0.78F + RANDOM.nextFloat() * 0.25F, false);
            ambientCooldown = 1200 + RANDOM.nextInt(2400);
            if (RANDOM.nextFloat() < 0.35F) distortion = 35 + RANDOM.nextInt(35);
        }

        boolean threatened = mc.player.getHealth() <= mc.player.getMaxHealth() * 0.55F;
        if (threatened && --heartbeatCooldown <= 0) {
            mc.level.playLocalSound(mc.player.blockPosition(), ModSounds.HEARTBEAT.get(),
                    SoundSource.PLAYERS, 0.72F, 0.92F + RANDOM.nextFloat() * 0.16F, false);
            heartbeatCooldown = 24;
        } else if (!threatened) {
            heartbeatCooldown = 0;
        }
    }

    @SubscribeEvent
    public static void fog(ViewportEvent.RenderFog event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        // A short, oppressive view distance gives the world its analog-horror silhouette.
        event.setNearPlaneDistance(-6.0F);
        event.setFarPlaneDistance(30.0F);
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("signal_distortion", (gui, graphics, partialTick, width, height) -> {
            if (distortion <= 0) return;
            RenderSystem.enableBlend();
            int alpha = Math.min(90, distortion * 2);
            graphics.fill(0, 0, width, height, (alpha << 24) | 0x650000);
            // Broken horizontal scan lines and angular crack fragments.
            for (int i = 0; i < 7; i++) {
                int y = RANDOM.nextInt(Math.max(1, height));
                graphics.fill(0, y, width, y + 1, 0x55D9D9D9);
            }
            int cx = width / 2 + RANDOM.nextInt(81) - 40;
            int cy = height / 2 + RANDOM.nextInt(61) - 30;
            for (int i = 0; i < 9; i++) {
                int x2 = cx + RANDOM.nextInt(100) - 50;
                int y2 = cy + RANDOM.nextInt(100) - 50;
                int left = Math.min(cx, x2), top = Math.min(cy, y2);
                int w = Math.max(1, Math.abs(x2 - cx));
                int h = Math.max(1, Math.abs(y2 - cy));
                graphics.fill(left, top, left + w, top + h, 0x88D8D8D8);
                cx = x2; cy = y2;
            }
            RenderSystem.disableBlend();
        });
    }

    public static void triggerScare(int ticks) {
        distortion = Math.max(distortion, ticks);
    }
}
