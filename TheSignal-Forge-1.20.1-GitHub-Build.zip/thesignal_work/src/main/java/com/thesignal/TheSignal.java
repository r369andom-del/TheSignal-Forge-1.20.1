package com.thesignal;

import com.mojang.logging.LogUtils;
import com.thesignal.registry.ModEntities;
import com.thesignal.registry.ModItems;
import com.thesignal.registry.ModSounds;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(TheSignal.MODID)
public class TheSignal {
    public static final String MODID = "thesignal";
    public static final Logger LOGGER = LogUtils.getLogger();

    public TheSignal() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITY_TYPES.register(bus);
        ModItems.ITEMS.register(bus);
        ModSounds.SOUNDS.register(bus);
    }
}
