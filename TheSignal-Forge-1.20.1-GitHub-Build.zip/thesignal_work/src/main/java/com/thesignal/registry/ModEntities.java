package com.thesignal.registry;

import com.thesignal.TheSignal;
import com.thesignal.entity.StalkerEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, TheSignal.MODID);

    public static final RegistryObject<EntityType<StalkerEntity>> STALKER =
            ENTITY_TYPES.register("stalker", () -> EntityType.Builder
                    .of(StalkerEntity::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.8F).clientTrackingRange(64).updateInterval(1)
                    .build("stalker"));
}
